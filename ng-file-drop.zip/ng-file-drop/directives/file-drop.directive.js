import { Directive, EventEmitter, ElementRef, Renderer, HostListener, Output, Input } from '@angular/core';
import { FileState } from '../utilities/file-state';
import { DropZoneStyle } from '../utilities/drop-zone-style';
import { RejectionReasons } from '../properties/rejection-reasons';
import { AcceptedFile } from '../dropped-files/accepted-file';
import { RejectedFile } from '../dropped-files/rejected-file';
//
// Directive to support dragging and dropping and element onto a div
//
var FileDropDirective = (function () {
    //
    // Constructor requires an element reference that instantiated this directive
    //
    function FileDropDirective(element, renderer) {
        this.element = element;
        this.renderer = renderer;
        this.ng2FileDropHoverStart = new EventEmitter();
        this.ng2FileDropHoverEnd = new EventEmitter();
        this.ng2FileDropFileAccepted = new EventEmitter();
        this.ng2FileDropFileRejected = new EventEmitter();
        this.ng2FileDropFilesDropped = new EventEmitter();
        // Keep track of our dropped files
        this.fileService = new FileState();
        this.dropZoneStyle = null;
    }
    //
    // Initialisation
    //
    FileDropDirective.prototype.ngOnInit = function () {
        // Set our properties
        this.fileService.setExpectedFileProperties(this.ng2FileDropSupportedFileTypes, this.ng2FileDropMaximumSizeBytes);
        if (this.ng2FileDropDisableStyles !== true) {
            this.dropZoneStyle = new DropZoneStyle(this.element, this.renderer);
        }
    };
    //
    // Called when the element has content dragged over
    //
    FileDropDirective.prototype.onDragOver = function (event) {
        // If we're already in the on-drag, don't bother with this
        if (this.fileService.currentFile === null) {
            // Get the object being dragged and reference it as a copy action
            this.fileService.currentFile = this.getDataTransferObject(event);
            if (this.fileService.currentFile === null) {
                return;
            }
            // Let the client know
            this.ng2FileDropHoverStart.emit();
            if (this.dropZoneStyle !== null) {
                this.dropZoneStyle.onHoverStart();
            }
        }
        // Don't propagate
        this.preventAndStopEventPropagation(event);
    };
    //
    // Called when the element has dragged content leave
    //
    FileDropDirective.prototype.onDragLeave = function (event) {
        // Only bother if we have a file
        if (this.fileService.currentFile !== null) {
            // Finished with the file
            this.fileService.currentFile = null;
            if (event.currentTarget === this.element[0]) {
                return;
            }
            // Let the client know
            this.ng2FileDropHoverEnd.emit();
            if (this.dropZoneStyle !== null) {
                this.dropZoneStyle.onHoverEnd();
            }
        }
        // Don't let it continue
        this.preventAndStopEventPropagation(event);
    };
    //
    // Called when the element has content dropped
    //
    FileDropDirective.prototype.onDrop = function (event) {
        // Only bother if we have a file
        if (this.fileService.currentFile !== null) {
            // Let the client know
            this.ng2FileDropHoverEnd.emit();
            if (this.dropZoneStyle !== null) {
                this.dropZoneStyle.onHoverEnd();
            }
            // Update our data
            this.fileService.currentFile = this.getDataTransferObject(event);
            if (this.ng2FileDropAcceptMultiple) {
                // Check if our files are valid or not
                var droppedFiles = this.fileService.verifyFiles();
                this.ng2FileDropFilesDropped.emit(droppedFiles);
                if (this.dropZoneStyle !== null) {
                    if (droppedFiles.areAllAccepted()) {
                        this.dropZoneStyle.onFileAccepted();
                    }
                    else {
                        this.dropZoneStyle.onFileRejected();
                    }
                }
            }
            else {
                // Check if our file is valid or not
                var rejectionReason = this.fileService.isFileValid();
                var fileData = void 0;
                var files = this.fileService.getFiles();
                if (files !== null) {
                    fileData = files[0];
                    if (rejectionReason === RejectionReasons.None) {
                        this.ng2FileDropFileAccepted.emit(new AcceptedFile(fileData));
                        if (this.dropZoneStyle !== null) {
                            this.dropZoneStyle.onFileAccepted();
                        }
                    }
                    else {
                        this.ng2FileDropFileRejected.emit(new RejectedFile(fileData, rejectionReason));
                        if (this.dropZoneStyle !== null) {
                            this.dropZoneStyle.onFileRejected();
                        }
                    }
                }
            }
            // Finished with the file
            this.fileService.currentFile = null;
        }
        // Don't let it continue
        this.preventAndStopEventPropagation(event);
    };
    //
    // Stops the drag/drop events propagating
    //
    FileDropDirective.prototype.preventAndStopEventPropagation = function (event) {
        event.preventDefault();
        event.stopPropagation();
    };
    //
    // Returns the file dragged into the directive
    //
    FileDropDirective.prototype.getDataTransferObject = function (event) {
        return event.dataTransfer ? event.dataTransfer : event.originalEvent.dataTransfer;
    };
    return FileDropDirective;
}());
export { FileDropDirective };
FileDropDirective.decorators = [
    { type: Directive, args: [{
                // Selector required in component HTML
                selector: '[ng2FileDrop]',
            },] },
];
/** @nocollapse */
FileDropDirective.ctorParameters = function () { return [
    { type: ElementRef, },
    { type: Renderer, },
]; };
FileDropDirective.propDecorators = {
    'ng2FileDropHoverStart': [{ type: Output },],
    'ng2FileDropHoverEnd': [{ type: Output },],
    'ng2FileDropFileAccepted': [{ type: Output },],
    'ng2FileDropFileRejected': [{ type: Output },],
    'ng2FileDropFilesDropped': [{ type: Output },],
    'ng2FileDropAcceptMultiple': [{ type: Input },],
    'ng2FileDropSupportedFileTypes': [{ type: Input },],
    'ng2FileDropMaximumSizeBytes': [{ type: Input },],
    'ng2FileDropDisableStyles': [{ type: Input },],
    'onDragOver': [{ type: HostListener, args: ['dragover', ['$event'],] },],
    'onDragLeave': [{ type: HostListener, args: ['dragleave', ['$event'],] },],
    'onDrop': [{ type: HostListener, args: ['drop', ['$event'],] },],
};
//# sourceMappingURL=file-drop.directive.js.map