//
// Properties of a rejected file
//
var RejectedFile = (function () {
    // Constructs the object
    function RejectedFile(acceptedFile, reason) {
        this.acceptedFile = acceptedFile;
        this.reason = reason;
    }
    Object.defineProperty(RejectedFile.prototype, "file", {
        // Return the file
        get: function () {
            return this.acceptedFile;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RejectedFile.prototype, "rejectionReason", {
        // Return the reason we rejected this file
        get: function () {
            return this.reason;
        },
        enumerable: true,
        configurable: true
    });
    return RejectedFile;
}());
export { RejectedFile };
//# sourceMappingURL=rejected-file.js.map