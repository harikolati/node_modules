export declare class AcceptedFile {
    private acceptedFile;
    readonly file: File;
    constructor(acceptedFile: File);
}
