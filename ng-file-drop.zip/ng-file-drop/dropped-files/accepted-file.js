//
// Properties of an accepted file
//
var AcceptedFile = (function () {
    // Constructs the object
    function AcceptedFile(acceptedFile) {
        this.acceptedFile = acceptedFile;
    }
    Object.defineProperty(AcceptedFile.prototype, "file", {
        // Return the file
        get: function () {
            return this.acceptedFile;
        },
        enumerable: true,
        configurable: true
    });
    return AcceptedFile;
}());
export { AcceptedFile };
//# sourceMappingURL=accepted-file.js.map