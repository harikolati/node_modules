export declare enum RejectionReasons {
    None = 0,
    FileType = 1,
    FileSize = 2,
    Unknown = 3,
}
