//
// Reasons for files to be rejected
//
export var RejectionReasons;
(function (RejectionReasons) {
    RejectionReasons[RejectionReasons["None"] = 0] = "None";
    RejectionReasons[RejectionReasons["FileType"] = 1] = "FileType";
    RejectionReasons[RejectionReasons["FileSize"] = 2] = "FileSize";
    RejectionReasons[RejectionReasons["Unknown"] = 3] = "Unknown";
})(RejectionReasons || (RejectionReasons = {}));
//# sourceMappingURL=rejection-reasons.js.map