//
// Color indicies
//
export var ColorIndex;
(function (ColorIndex) {
    ColorIndex[ColorIndex["Red"] = 0] = "Red";
    ColorIndex[ColorIndex["Green"] = 1] = "Green";
    ColorIndex[ColorIndex["Blue"] = 2] = "Blue";
})(ColorIndex || (ColorIndex = {}));
//# sourceMappingURL=color-index.js.map