export declare class FileDropModule {
}
