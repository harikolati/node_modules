import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FileDropDirective } from '../directives/file-drop.directive';
//
// Main entry module for the application
//
var FileDropModule = (function () {
    function FileDropModule() {
    }
    return FileDropModule;
}());
export { FileDropModule };
FileDropModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                ],
                declarations: [
                    FileDropDirective,
                ],
                providers: [],
                exports: [
                    FileDropDirective,
                ],
            },] },
];
/** @nocollapse */
FileDropModule.ctorParameters = function () { return []; };
//# sourceMappingURL=file-drop.module.js.map