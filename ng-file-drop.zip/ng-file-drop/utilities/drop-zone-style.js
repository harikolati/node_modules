import { ColorIndex } from '../properties/color-index';
import { TsLerp, TsLerpStyle, TsLerpTransition } from 'tslerp2';
//
// Manages the presentation of the drop zone
//
var DropZoneStyle = (function () {
    //
    // Entry point
    //
    function DropZoneStyle(element, renderer) {
        this.element = element;
        this.renderer = renderer;
        // Default colours
        this.defaultIdleColor = [255, 255, 255];
        this.defaultHoverColor = [187, 215, 252];
        this.defaultRejectedColor = [255, 191, 191];
        this.currentElementColour = this.defaultIdleColor;
        this.lerpController = new TsLerp();
        this.transitionTime = 0.5;
    }
    //
    // Called when a hover starts
    //
    DropZoneStyle.prototype.onHoverStart = function () {
        this.startColourTransition(this.defaultHoverColor, TsLerpTransition.EaseOut, TsLerpStyle.Sine);
    };
    //
    // Called when a hover ends
    //
    DropZoneStyle.prototype.onHoverEnd = function () {
        this.startColourTransition(this.defaultIdleColor, TsLerpTransition.EaseIn, TsLerpStyle.Sine);
    };
    //
    // Called when a file is rejected
    //
    DropZoneStyle.prototype.onFileRejected = function () {
        // Slightly different, we flash fail and fade out
        this.currentElementColour = this.defaultRejectedColor;
        this.startColourTransition(this.defaultIdleColor, TsLerpTransition.EaseIn, TsLerpStyle.Cubic);
    };
    //
    // Called when a file is accepted
    //
    DropZoneStyle.prototype.onFileAccepted = function () {
        // We won't do anything with this by default
    };
    //
    // Converts an RGB to a Hex value
    //
    DropZoneStyle.prototype.convertRgbToHex = function (rgb) {
        // Return our hex value
        return '#' + this.componentToHex(rgb[ColorIndex.Red]) +
            this.componentToHex(rgb[ColorIndex.Green]) +
            this.componentToHex(rgb[ColorIndex.Blue]);
    };
    //
    // Converts a single RGB colour component to hex
    //
    DropZoneStyle.prototype.componentToHex = function (component) {
        // Found it first, we don't deal with non-integer values
        component = Math.round(component);
        var hex = component.toString(16);
        return hex.length === 1 ? '0' + hex : hex;
    };
    //
    // Starts a colour transition
    //
    DropZoneStyle.prototype.startColourTransition = function (target, transition, style) {
        var _this = this;
        // Define the lerp for from where we are originally
        this.lerpController.define([
            [this.currentElementColour[ColorIndex.Red], target[ColorIndex.Red]],
            [this.currentElementColour[ColorIndex.Green], target[ColorIndex.Green]],
            [this.currentElementColour[ColorIndex.Blue], target[ColorIndex.Blue]],
        ], this.transitionTime, transition, style);
        // Trigger it
        this.lerpController.lerp(function (lerpResults, time) {
            _this.updateColourLerp(lerpResults, time);
        });
    };
    //
    // Callback during the lerp
    //
    DropZoneStyle.prototype.updateColourLerp = function (lerpResults, time) {
        // Update our element colour
        this.currentElementColour = lerpResults;
        this.updateElementColour();
    };
    //
    // Updates the colour of the element
    //
    DropZoneStyle.prototype.updateElementColour = function () {
        // Set it to the default colour
        var endColor = this.convertRgbToHex(this.currentElementColour);
        this.renderer.setElementStyle(this.element.nativeElement, 'backgroundColor', endColor);
    };
    return DropZoneStyle;
}());
export { DropZoneStyle };
//# sourceMappingURL=drop-zone-style.js.map