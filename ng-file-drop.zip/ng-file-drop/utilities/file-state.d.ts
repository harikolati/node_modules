import { RejectionReasons } from '../properties/rejection-reasons';
import { DroppedFiles } from '../dropped-files/dropped-files';
export declare class FileState {
    private currentObject;
    private supportedFileTypes;
    private maximumFileSizeInBytes;
    currentFile: DataTransfer | null;
    setExpectedFileProperties(supportFileFormats: string[], maximumFileSize: number): void;
    getFiles(): FileList | null;
    isFileValid(): RejectionReasons;
    verifyFiles(): DroppedFiles;
}
