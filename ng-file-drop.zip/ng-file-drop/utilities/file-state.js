import { RejectionReasons } from '../properties/rejection-reasons';
import { AcceptedFile } from '../dropped-files/accepted-file';
import { RejectedFile } from '../dropped-files/rejected-file';
import { DroppedFiles } from '../dropped-files/dropped-files';
//
// Tracks and manages dragged files
//
var FileState = (function () {
    function FileState() {
        // Private properties
        this.currentObject = null;
        this.supportedFileTypes = null;
        this.maximumFileSizeInBytes = 0;
    }
    Object.defineProperty(FileState.prototype, "currentFile", {
        //
        // Provides access to the current file object
        //
        get: function () {
            return this.currentObject;
        },
        set: function (thisFile) {
            this.currentObject = thisFile;
            if (this.currentObject !== null) {
                this.currentObject.dropEffect = 'copy';
            }
        },
        enumerable: true,
        configurable: true
    });
    //
    // Sets our expected properties for the file we're dragging
    //
    FileState.prototype.setExpectedFileProperties = function (supportFileFormats, maximumFileSize) {
        this.supportedFileTypes = supportFileFormats;
        this.maximumFileSizeInBytes = maximumFileSize;
    };
    //
    // Returns the actual files present in the transfer object
    //
    FileState.prototype.getFiles = function () {
        // We need an object
        if (this.currentObject === null) {
            return null;
        }
        if (this.currentObject.files.length === 0) {
            return null;
        }
        // Return all files
        return this.currentObject.files;
    };
    //
    // Verifies if the file we have is valid or needs to be rejected
    //
    FileState.prototype.isFileValid = function () {
        // Get the file
        var currentFiles = this.getFiles();
        if (currentFiles === null) {
            return RejectionReasons.Unknown;
        }
        // Valid file types
        if (this.supportedFileTypes) {
            // See if this is a type we support
            var fileTypeIndex = this.supportedFileTypes.indexOf(currentFiles[0].type);
            if (fileTypeIndex === -1) {
                return RejectionReasons.FileType;
            }
        }
        // File size
        if (this.maximumFileSizeInBytes) {
            if (this.maximumFileSizeInBytes < currentFiles[0].size) {
                return RejectionReasons.FileSize;
            }
        }
        // No problem
        return RejectionReasons.None;
    };
    //
    // Verifies if the files we have are valid or needs to be rejected
    //
    FileState.prototype.verifyFiles = function () {
        // Get the files
        var currentFiles = this.getFiles();
        if (currentFiles === null) {
            return new DroppedFiles();
        }
        var acceptedFiles = [];
        var rejectedFiles = [];
        for (var i = 0; i < currentFiles.length; ++i) {
            // Valid file types
            if (this.supportedFileTypes) {
                // See if this is a type we support
                var fileTypeIndex = this.supportedFileTypes.indexOf(currentFiles[i].type);
                if (fileTypeIndex === -1) {
                    rejectedFiles.push(new RejectedFile(currentFiles[i], RejectionReasons.FileType));
                    continue;
                }
            }
            // File size
            if (this.maximumFileSizeInBytes) {
                if (this.maximumFileSizeInBytes < currentFiles[i].size) {
                    rejectedFiles.push(new RejectedFile(currentFiles[i], RejectionReasons.FileSize));
                    continue;
                }
            }
            // No problem
            acceptedFiles.push(new AcceptedFile(currentFiles[i]));
        }
        return new DroppedFiles(acceptedFiles, rejectedFiles);
    };
    return FileState;
}());
export { FileState };
//# sourceMappingURL=file-state.js.map