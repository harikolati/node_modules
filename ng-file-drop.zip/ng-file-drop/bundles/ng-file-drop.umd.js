(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('@angular/common'), require('tslerp2')) :
	typeof define === 'function' && define.amd ? define(['exports', '@angular/core', '@angular/common', 'tslerp2'], factory) :
	(factory((global.ng = global.ng || {}, global.ng.filedrop = global.ng.filedrop || {}),global.ng.core,global.ng.common,global.tslerp2));
}(this, (function (exports,_angular_core,_angular_common,tslerp2) { 'use strict';

//
// Reasons for files to be rejected
//

(function (RejectionReasons) {
    RejectionReasons[RejectionReasons["None"] = 0] = "None";
    RejectionReasons[RejectionReasons["FileType"] = 1] = "FileType";
    RejectionReasons[RejectionReasons["FileSize"] = 2] = "FileSize";
    RejectionReasons[RejectionReasons["Unknown"] = 3] = "Unknown";
})(exports.RejectionReasons || (exports.RejectionReasons = {}));

//
// Properties of an accepted file
//
var AcceptedFile = (function () {
    // Constructs the object
    function AcceptedFile(acceptedFile) {
        this.acceptedFile = acceptedFile;
    }
    Object.defineProperty(AcceptedFile.prototype, "file", {
        // Return the file
        get: function () {
            return this.acceptedFile;
        },
        enumerable: true,
        configurable: true
    });
    return AcceptedFile;
}());

//
// Properties of a rejected file
//
var RejectedFile = (function () {
    // Constructs the object
    function RejectedFile(acceptedFile, reason) {
        this.acceptedFile = acceptedFile;
        this.reason = reason;
    }
    Object.defineProperty(RejectedFile.prototype, "file", {
        // Return the file
        get: function () {
            return this.acceptedFile;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(RejectedFile.prototype, "rejectionReason", {
        // Return the reason we rejected this file
        get: function () {
            return this.reason;
        },
        enumerable: true,
        configurable: true
    });
    return RejectedFile;
}());

var DroppedFiles = (function () {
    // Constructs the object
    function DroppedFiles(acceptedFiles, rejectedFiles) {
        if (acceptedFiles === void 0) { acceptedFiles = []; }
        if (rejectedFiles === void 0) { rejectedFiles = []; }
        this.acceptedFiles = acceptedFiles;
        this.rejectedFiles = rejectedFiles;
    }
    Object.defineProperty(DroppedFiles.prototype, "accepted", {
        // Return the accepted files
        get: function () {
            return this.acceptedFiles;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(DroppedFiles.prototype, "rejected", {
        // Return the rejected files
        get: function () {
            return this.rejectedFiles;
        },
        enumerable: true,
        configurable: true
    });
    DroppedFiles.prototype.areAllAccepted = function () {
        return this.acceptedFiles.length > 0 && this.rejectedFiles.length === 0;
    };
    return DroppedFiles;
}());

//
// Tracks and manages dragged files
//
var FileState = (function () {
    function FileState() {
        // Private properties
        this.currentObject = null;
        this.supportedFileTypes = null;
        this.maximumFileSizeInBytes = 0;
    }
    Object.defineProperty(FileState.prototype, "currentFile", {
        //
        // Provides access to the current file object
        //
        get: function () {
            return this.currentObject;
        },
        set: function (thisFile) {
            this.currentObject = thisFile;
            if (this.currentObject !== null) {
                this.currentObject.dropEffect = 'copy';
            }
        },
        enumerable: true,
        configurable: true
    });
    //
    // Sets our expected properties for the file we're dragging
    //
    FileState.prototype.setExpectedFileProperties = function (supportFileFormats, maximumFileSize) {
        this.supportedFileTypes = supportFileFormats;
        this.maximumFileSizeInBytes = maximumFileSize;
    };
    //
    // Returns the actual files present in the transfer object
    //
    FileState.prototype.getFiles = function () {
        // We need an object
        if (this.currentObject === null) {
            return null;
        }
        if (this.currentObject.files.length === 0) {
            return null;
        }
        // Return all files
        return this.currentObject.files;
    };
    //
    // Verifies if the file we have is valid or needs to be rejected
    //
    FileState.prototype.isFileValid = function () {
        // Get the file
        var currentFiles = this.getFiles();
        if (currentFiles === null) {
            return exports.RejectionReasons.Unknown;
        }
        // Valid file types
        if (this.supportedFileTypes) {
            // See if this is a type we support
            var fileTypeIndex = this.supportedFileTypes.indexOf(currentFiles[0].type);
            if (fileTypeIndex === -1) {
                return exports.RejectionReasons.FileType;
            }
        }
        // File size
        if (this.maximumFileSizeInBytes) {
            if (this.maximumFileSizeInBytes < currentFiles[0].size) {
                return exports.RejectionReasons.FileSize;
            }
        }
        // No problem
        return exports.RejectionReasons.None;
    };
    //
    // Verifies if the files we have are valid or needs to be rejected
    //
    FileState.prototype.verifyFiles = function () {
        // Get the files
        var currentFiles = this.getFiles();
        if (currentFiles === null) {
            return new DroppedFiles();
        }
        var acceptedFiles = [];
        var rejectedFiles = [];
        for (var i = 0; i < currentFiles.length; ++i) {
            // Valid file types
            if (this.supportedFileTypes) {
                // See if this is a type we support
                var fileTypeIndex = this.supportedFileTypes.indexOf(currentFiles[i].type);
                if (fileTypeIndex === -1) {
                    rejectedFiles.push(new RejectedFile(currentFiles[i], exports.RejectionReasons.FileType));
                    continue;
                }
            }
            // File size
            if (this.maximumFileSizeInBytes) {
                if (this.maximumFileSizeInBytes < currentFiles[i].size) {
                    rejectedFiles.push(new RejectedFile(currentFiles[i], exports.RejectionReasons.FileSize));
                    continue;
                }
            }
            // No problem
            acceptedFiles.push(new AcceptedFile(currentFiles[i]));
        }
        return new DroppedFiles(acceptedFiles, rejectedFiles);
    };
    return FileState;
}());

//
// Color indicies
//
var ColorIndex;
(function (ColorIndex) {
    ColorIndex[ColorIndex["Red"] = 0] = "Red";
    ColorIndex[ColorIndex["Green"] = 1] = "Green";
    ColorIndex[ColorIndex["Blue"] = 2] = "Blue";
})(ColorIndex || (ColorIndex = {}));

//
// Manages the presentation of the drop zone
//
var DropZoneStyle = (function () {
    //
    // Entry point
    //
    function DropZoneStyle(element, renderer) {
        this.element = element;
        this.renderer = renderer;
        // Default colours
        this.defaultIdleColor = [255, 255, 255];
        this.defaultHoverColor = [187, 215, 252];
        this.defaultRejectedColor = [255, 191, 191];
        this.currentElementColour = this.defaultIdleColor;
        this.lerpController = new tslerp2.TsLerp();
        this.transitionTime = 0.5;
    }
    //
    // Called when a hover starts
    //
    DropZoneStyle.prototype.onHoverStart = function () {
        this.startColourTransition(this.defaultHoverColor, tslerp2.TsLerpTransition.EaseOut, tslerp2.TsLerpStyle.Sine);
    };
    //
    // Called when a hover ends
    //
    DropZoneStyle.prototype.onHoverEnd = function () {
        this.startColourTransition(this.defaultIdleColor, tslerp2.TsLerpTransition.EaseIn, tslerp2.TsLerpStyle.Sine);
    };
    //
    // Called when a file is rejected
    //
    DropZoneStyle.prototype.onFileRejected = function () {
        // Slightly different, we flash fail and fade out
        this.currentElementColour = this.defaultRejectedColor;
        this.startColourTransition(this.defaultIdleColor, tslerp2.TsLerpTransition.EaseIn, tslerp2.TsLerpStyle.Cubic);
    };
    //
    // Called when a file is accepted
    //
    DropZoneStyle.prototype.onFileAccepted = function () {
        // We won't do anything with this by default
    };
    //
    // Converts an RGB to a Hex value
    //
    DropZoneStyle.prototype.convertRgbToHex = function (rgb) {
        // Return our hex value
        return '#' + this.componentToHex(rgb[ColorIndex.Red]) +
            this.componentToHex(rgb[ColorIndex.Green]) +
            this.componentToHex(rgb[ColorIndex.Blue]);
    };
    //
    // Converts a single RGB colour component to hex
    //
    DropZoneStyle.prototype.componentToHex = function (component) {
        // Found it first, we don't deal with non-integer values
        component = Math.round(component);
        var hex = component.toString(16);
        return hex.length === 1 ? '0' + hex : hex;
    };
    //
    // Starts a colour transition
    //
    DropZoneStyle.prototype.startColourTransition = function (target, transition, style) {
        var _this = this;
        // Define the lerp for from where we are originally
        this.lerpController.define([
            [this.currentElementColour[ColorIndex.Red], target[ColorIndex.Red]],
            [this.currentElementColour[ColorIndex.Green], target[ColorIndex.Green]],
            [this.currentElementColour[ColorIndex.Blue], target[ColorIndex.Blue]],
        ], this.transitionTime, transition, style);
        // Trigger it
        this.lerpController.lerp(function (lerpResults, time) {
            _this.updateColourLerp(lerpResults, time);
        });
    };
    //
    // Callback during the lerp
    //
    DropZoneStyle.prototype.updateColourLerp = function (lerpResults, time) {
        // Update our element colour
        this.currentElementColour = lerpResults;
        this.updateElementColour();
    };
    //
    // Updates the colour of the element
    //
    DropZoneStyle.prototype.updateElementColour = function () {
        // Set it to the default colour
        var endColor = this.convertRgbToHex(this.currentElementColour);
        this.renderer.setElementStyle(this.element.nativeElement, 'backgroundColor', endColor);
    };
    return DropZoneStyle;
}());

//
// Directive to support dragging and dropping and element onto a div
//
var FileDropDirective = (function () {
    //
    // Constructor requires an element reference that instantiated this directive
    //
    function FileDropDirective(element, renderer) {
        this.element = element;
        this.renderer = renderer;
        this.ng2FileDropHoverStart = new _angular_core.EventEmitter();
        this.ng2FileDropHoverEnd = new _angular_core.EventEmitter();
        this.ng2FileDropFileAccepted = new _angular_core.EventEmitter();
        this.ng2FileDropFileRejected = new _angular_core.EventEmitter();
        this.ng2FileDropFilesDropped = new _angular_core.EventEmitter();
        // Keep track of our dropped files
        this.fileService = new FileState();
        this.dropZoneStyle = null;
    }
    //
    // Initialisation
    //
    FileDropDirective.prototype.ngOnInit = function () {
        // Set our properties
        this.fileService.setExpectedFileProperties(this.ng2FileDropSupportedFileTypes, this.ng2FileDropMaximumSizeBytes);
        if (this.ng2FileDropDisableStyles !== true) {
            this.dropZoneStyle = new DropZoneStyle(this.element, this.renderer);
        }
    };
    //
    // Called when the element has content dragged over
    //
    FileDropDirective.prototype.onDragOver = function (event) {
        // If we're already in the on-drag, don't bother with this
        if (this.fileService.currentFile === null) {
            // Get the object being dragged and reference it as a copy action
            this.fileService.currentFile = this.getDataTransferObject(event);
            if (this.fileService.currentFile === null) {
                return;
            }
            // Let the client know
            this.ng2FileDropHoverStart.emit();
            if (this.dropZoneStyle !== null) {
                this.dropZoneStyle.onHoverStart();
            }
        }
        // Don't propagate
        this.preventAndStopEventPropagation(event);
    };
    //
    // Called when the element has dragged content leave
    //
    FileDropDirective.prototype.onDragLeave = function (event) {
        // Only bother if we have a file
        if (this.fileService.currentFile !== null) {
            // Finished with the file
            this.fileService.currentFile = null;
            if (event.currentTarget === this.element[0]) {
                return;
            }
            // Let the client know
            this.ng2FileDropHoverEnd.emit();
            if (this.dropZoneStyle !== null) {
                this.dropZoneStyle.onHoverEnd();
            }
        }
        // Don't let it continue
        this.preventAndStopEventPropagation(event);
    };
    //
    // Called when the element has content dropped
    //
    FileDropDirective.prototype.onDrop = function (event) {
        // Only bother if we have a file
        if (this.fileService.currentFile !== null) {
            // Let the client know
            this.ng2FileDropHoverEnd.emit();
            if (this.dropZoneStyle !== null) {
                this.dropZoneStyle.onHoverEnd();
            }
            // Update our data
            this.fileService.currentFile = this.getDataTransferObject(event);
            if (this.ng2FileDropAcceptMultiple) {
                // Check if our files are valid or not
                var droppedFiles = this.fileService.verifyFiles();
                this.ng2FileDropFilesDropped.emit(droppedFiles);
                if (this.dropZoneStyle !== null) {
                    if (droppedFiles.areAllAccepted()) {
                        this.dropZoneStyle.onFileAccepted();
                    }
                    else {
                        this.dropZoneStyle.onFileRejected();
                    }
                }
            }
            else {
                // Check if our file is valid or not
                var rejectionReason = this.fileService.isFileValid();
                var fileData = void 0;
                var files = this.fileService.getFiles();
                if (files !== null) {
                    fileData = files[0];
                    if (rejectionReason === exports.RejectionReasons.None) {
                        this.ng2FileDropFileAccepted.emit(new AcceptedFile(fileData));
                        if (this.dropZoneStyle !== null) {
                            this.dropZoneStyle.onFileAccepted();
                        }
                    }
                    else {
                        this.ng2FileDropFileRejected.emit(new RejectedFile(fileData, rejectionReason));
                        if (this.dropZoneStyle !== null) {
                            this.dropZoneStyle.onFileRejected();
                        }
                    }
                }
            }
            // Finished with the file
            this.fileService.currentFile = null;
        }
        // Don't let it continue
        this.preventAndStopEventPropagation(event);
    };
    //
    // Stops the drag/drop events propagating
    //
    FileDropDirective.prototype.preventAndStopEventPropagation = function (event) {
        event.preventDefault();
        event.stopPropagation();
    };
    //
    // Returns the file dragged into the directive
    //
    FileDropDirective.prototype.getDataTransferObject = function (event) {
        return event.dataTransfer ? event.dataTransfer : event.originalEvent.dataTransfer;
    };
    return FileDropDirective;
}());
FileDropDirective.decorators = [
    { type: _angular_core.Directive, args: [{
                // Selector required in component HTML
                selector: '[ng2FileDrop]',
            },] },
];
/** @nocollapse */
FileDropDirective.ctorParameters = function () { return [
    { type: _angular_core.ElementRef, },
    { type: _angular_core.Renderer, },
]; };
FileDropDirective.propDecorators = {
    'ng2FileDropHoverStart': [{ type: _angular_core.Output },],
    'ng2FileDropHoverEnd': [{ type: _angular_core.Output },],
    'ng2FileDropFileAccepted': [{ type: _angular_core.Output },],
    'ng2FileDropFileRejected': [{ type: _angular_core.Output },],
    'ng2FileDropFilesDropped': [{ type: _angular_core.Output },],
    'ng2FileDropAcceptMultiple': [{ type: _angular_core.Input },],
    'ng2FileDropSupportedFileTypes': [{ type: _angular_core.Input },],
    'ng2FileDropMaximumSizeBytes': [{ type: _angular_core.Input },],
    'ng2FileDropDisableStyles': [{ type: _angular_core.Input },],
    'onDragOver': [{ type: _angular_core.HostListener, args: ['dragover', ['$event'],] },],
    'onDragLeave': [{ type: _angular_core.HostListener, args: ['dragleave', ['$event'],] },],
    'onDrop': [{ type: _angular_core.HostListener, args: ['drop', ['$event'],] },],
};

//
// Main entry module for the application
//
var FileDropModule = (function () {
    function FileDropModule() {
    }
    return FileDropModule;
}());
FileDropModule.decorators = [
    { type: _angular_core.NgModule, args: [{
                imports: [
                    _angular_common.CommonModule,
                ],
                declarations: [
                    FileDropDirective,
                ],
                providers: [],
                exports: [
                    FileDropDirective,
                ],
            },] },
];
/** @nocollapse */
FileDropModule.ctorParameters = function () { return []; };

exports.FileDropModule = FileDropModule;
exports.FileDropDirective = FileDropDirective;
exports.AcceptedFile = AcceptedFile;
exports.RejectedFile = RejectedFile;
exports.DroppedFiles = DroppedFiles;

Object.defineProperty(exports, '__esModule', { value: true });

})));
